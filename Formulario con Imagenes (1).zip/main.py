from flask import Flask, render_template, request, redirect, url_for

from forms import SignupForm, PostForm

app = Flask(__name__)
# la llave o SECRET_KEY me ayuda a poder guardar las contraseñas de forma segura
app.config['SECRET_KEY'] = '7110c8ae51a4b5af97be6534caef90e4bb9bdcb3380af008f90b23a5d1616bf319bc298105da20fee'
# app.config['SECRET_KEY'] = 'pass'


@app.route("/")
def index():
    return render_template("index.html", posts=publicaciones)


@app.route('/pagina2')
def pagina2():
    return render_template('pagina2.html')


@app.route("/signup/", methods=["GET", "POST"])
def show_signup_form():
    # creamos el objeto form de la clase SignupForm() que está en forms.py
    form = SignupForm()
    # verificamos cuando el usuario haga click en submit (botón Registrar)
    if form.validate_on_submit():
        # si ha pasado la validación, creamos las siguientes variables
        # y obtenemos sus datos:
        name = form.name.data
        email = form.email.data
        password = form.password.data
        try:
            with open("usuarios.txt", "a+") as archivo1:
                archivo1.write(f"{name}, {email}, {password}\n")
        finally:
            archivo1.close()
        next = request.args.get('next', None)
        if next:
            return redirect(next)
        # redigire a la página principal!
        return redirect(url_for('index'))
    # caso contrario, redirige a signup_form con el contenido de form.
    return render_template("/admin/signup_form.html", form=form)

# publicaciones es una lista vacía
publicaciones = []
@app.route("/admin/post/", methods=['GET', 'POST'], defaults={'post_id': None})
@app.route("/admin/post/<int:post_id>/", methods=['GET', 'POST'])
def post_form(post_id):
    # form es un objeto de la clase PostForm
    form = PostForm()
    # si yo hago click en Enviar, y la validación ha sido correcta:
    if form.validate_on_submit():
        # obtengo el title
        title = form.title.data
        # obtengo el title slug
        title_slug = form.title_slug.data
        # obtengo el contenido del texto
        content = form.content.data
        # post es un diccionario con title, title_slug y content
        post = {'title': title, 'title_slug': title_slug, 'content': content}
        # agregar el post creado en la lista 'publicaciones'
        publicaciones.append(post)
        try:
            with open("publicaciones.txt", "a+") as archivo1:
                archivo1.write(f"{post}\n")
        finally:
            archivo1.close()
        return redirect(url_for('index'))
    return render_template("/admin/post_form.html", form=form)


if __name__ == '__main__':
    try:
        # abrir publicaciones.txt en modo lectura!
        with open("publicaciones.txt", "r") as archivo1:
            # publicaciones_ tiene los elementos como str en una lista
            publicaciones_ = archivo1.readlines()
        # hasta el momento tenemos una lista de cadenas
    finally:
        archivo1.close() # <--- finalizar la lectura del archivo
        for publicacion_ in publicaciones_: # recorrer los str de la lista
            d_publicacion = eval(publicacion_) # convetir str a diccionario
            publicaciones.append(d_publicacion) # append de los diccionarios
    d1 = {'title':'Titulo 1', 'title_slug':'Soy otro ejemplo!!'}
    publicaciones.append(d1)
    app.run(debug=True)
